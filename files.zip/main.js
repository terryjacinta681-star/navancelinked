const { app, BrowserWindow, Tray, Menu, ipcMain, screen, shell, nativeImage } = require('electron');
const path = require('path');
const fs = require('fs');

const ICON = path.join(__dirname, 'build', 'icon.png');

let win = null;
let tray = null;
let anchor = null;      // bottom-right corner of the bar on screen {right, bottom}
let placed = false;
let prefs = {};

const prefsFile = () => path.join(app.getPath('userData'), 'lv-prefs.json');
function loadPrefs() { try { return JSON.parse(fs.readFileSync(prefsFile(), 'utf8')); } catch (e) { return {}; } }
function savePrefs() { try { fs.writeFileSync(prefsFile(), JSON.stringify(prefs)); } catch (e) {} }

const alwaysOnTop = () => prefs.alwaysOnTop !== false;
const startsWithWindows = () => app.getLoginItemSettings().openAtLogin;

function pointOnScreen(pt) {
  return screen.getAllDisplays().some(d => {
    const b = d.bounds;
    return pt.x >= b.x && pt.x <= b.x + b.width && pt.y >= b.y && pt.y <= b.y + b.height;
  });
}

function createWindow() {
  win = new BrowserWindow({
    width: 420, height: 80, show: false,
    frame: false, transparent: true, backgroundColor: '#00000000',
    resizable: false, maximizable: false, fullscreenable: false,
    hasShadow: false, skipTaskbar: true,
    alwaysOnTop: alwaysOnTop(),
    icon: ICON,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false
    }
  });

  win.setMenuBarVisibility(false);
  win.loadFile('index.html');

  // shortcuts open in your normal browser, not inside the bar
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', e => e.preventDefault());

  // remember where you drop it
  win.on('moved', () => {
    const b = win.getBounds();
    anchor = { right: b.x + b.width, bottom: b.y + b.height };
    prefs.anchor = anchor;
    savePrefs();
  });
}

// The page tells us how big the bar (or the bar + settings) is. We resize the
// window to match and keep the bottom-right corner fixed.
ipcMain.on('lv:fit', (e, size) => {
  if (!win) return;

  if (!anchor) {
    const saved = prefs.anchor;
    if (saved && pointOnScreen({ x: saved.right - 1, y: saved.bottom - 1 })) {
      anchor = saved;
    } else {
      const wa = screen.getPrimaryDisplay().workArea;
      anchor = { right: wa.x + wa.width - 16, bottom: wa.y + wa.height - 16 };
    }
  }

  const wa = screen.getDisplayNearestPoint({ x: anchor.right - 1, y: anchor.bottom - 1 }).workArea;
  const w = Math.min(Math.max(40, Math.ceil(size.w)), wa.width);
  const h = Math.min(Math.max(30, Math.ceil(size.h)), wa.height);
  const x = Math.min(Math.max(anchor.right - w, wa.x), wa.x + wa.width - w);
  const y = Math.min(Math.max(anchor.bottom - h, wa.y), wa.y + wa.height - h);

  win.setBounds({ x, y, width: w, height: h });

  if (!placed) { placed = true; win.show(); }
});

function setTop(v) {
  prefs.alwaysOnTop = !!v;
  savePrefs();
  if (win) win.setAlwaysOnTop(!!v);
  buildTray();
}
function setLogin(v) {
  app.setLoginItemSettings({ openAtLogin: !!v });
  buildTray();
}

ipcMain.handle('lv:get-prefs', () => ({ alwaysOnTop: alwaysOnTop(), startWithWindows: startsWithWindows() }));
ipcMain.on('lv:set-pref', (e, key, value) => {
  if (key === 'alwaysOnTop') setTop(value);
  if (key === 'startWithWindows') setLogin(value);
});
ipcMain.on('lv:quit', () => app.quit());

function buildTray() {
  if (!tray) {
    tray = new Tray(nativeImage.createFromPath(ICON).resize({ width: 16, height: 16 }));
    tray.setToolTip('LV Quick Bar');
    tray.on('click', () => { if (win) { win.isVisible() ? win.hide() : win.show(); } });
  }
  tray.setContextMenu(Menu.buildFromTemplate([
    { label: 'Show / hide bar', click: () => { if (win) { win.isVisible() ? win.hide() : win.show(); } } },
    { label: 'Always on top', type: 'checkbox', checked: alwaysOnTop(), click: i => setTop(i.checked) },
    { label: 'Start with Windows', type: 'checkbox', checked: startsWithWindows(), click: i => setLogin(i.checked) },
    { type: 'separator' },
    { label: 'Quit', click: () => app.quit() }
  ]));
}

if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on('second-instance', () => { if (win) win.show(); });
  app.whenReady().then(() => {
    Menu.setApplicationMenu(null);
    prefs = loadPrefs();
    createWindow();
    buildTray();
  });
  app.on('window-all-closed', () => app.quit());
}
