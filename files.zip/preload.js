const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('lv', {
  fit: (w, h) => ipcRenderer.send('lv:fit', { w, h }),
  getPrefs: () => ipcRenderer.invoke('lv:get-prefs'),
  setPref: (key, value) => ipcRenderer.send('lv:set-pref', key, value),
  quit: () => ipcRenderer.send('lv:quit')
});
